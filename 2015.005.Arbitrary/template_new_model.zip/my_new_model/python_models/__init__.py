from spynnaker.pyNN.spinnaker import executable_finder
from python_models import model_binaries

# TODO: Add any additional models you create here
from python_models.neural_models.my_model_curr_exp import MyModelCurrExp

import os

# This adds the model binaries path to the paths searched by sPyNNaker
executable_finder.add_path(os.path.dirname(model_binaries.__file__))
