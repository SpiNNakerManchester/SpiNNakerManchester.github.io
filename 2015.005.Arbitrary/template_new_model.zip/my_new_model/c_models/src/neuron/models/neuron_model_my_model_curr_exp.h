#ifndef _NEURON_MODEL_MY_IMPL_H_
#define _NEURON_MODEL_MY_IMPL_H_

#include <neuron/models/neuron_model.h>

typedef struct neuron_t {

    // TODO: Parameters - make sure these match with the python code,
    // including the order of the variables when returned by get_parameters.

    // Variable-state parameters e.g. membrane voltage
    REAL V;

    // offset current [nA]
    REAL I_offset;

    // Put anything else you want to store per neuron
    REAL my_parameter;

} neuron_t;

typedef struct global_neuron_params_t {

    // Add any parameters that apply to the whole model here
    REAL my_parameter;

} global_neuron_params_t;

// function that converts the input into the real value to be used by the
// neuron - this can be used for scaling for example
// (as is done for conductance)
// TODO: Ensure that any scaling requested by the python weight_scale
// is reversed at this point
inline input_t neuron_model_convert_input(input_t input) {
    return input;
}

#endif   // _NEURON_MODEL_MY_IMPL_H_
