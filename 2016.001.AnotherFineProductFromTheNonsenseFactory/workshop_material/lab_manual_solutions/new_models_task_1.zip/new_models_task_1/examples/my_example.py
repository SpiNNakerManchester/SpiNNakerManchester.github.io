import pyNN.spiNNaker as p
import pylab
import python_models as new_models

# Set the run time of the execution
run_time = 1000

# Set the time step of the simulation in milliseconds
time_step = 1.0

# Set the number of neurons to simulate
n_neurons = 1

# Set the i_offset current
i_offset = 0.0

# Set the weight of input spikes
weight = 2.0

# Set the times at which to input a spike
spike_times = range(0, run_time, 100)


# A function to create a graph of voltage against time
def create_v_graph(population, title):
    v = population.get_v()
    if v is not None:
        ticks = len(v) / n_neurons
        pylab.figure()
        pylab.xlabel('Time (ms)')
        pylab.ylabel("Membrane Voltage")
        pylab.title(title)

        for pos in range(n_neurons):
            v_for_neuron = v[pos * ticks: (pos + 1) * ticks]
            pylab.plot([i[1] for i in v_for_neuron],
                       [i[2] for i in v_for_neuron])

p.setup(time_step)

input_pop = p.Population(
    1, p.SpikeSourceArray, {"spike_times": spike_times}, label="input")

my_model_pop = p.Population(
    1, new_models.MyModelCurrExp,
    {"i_offset": i_offset},
    label="my_model_pop")
p.Projection(input_pop, my_model_pop, p.OneToOneConnector(weights=weight))

my_model_pop.record_v()

p.run(run_time)

create_v_graph(my_model_pop, "My Model")
pylab.show()
