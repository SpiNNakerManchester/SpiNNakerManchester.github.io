from setuptools import setup

setup(
    name="REPLACE_WITH_MODULE_NAME",
    version="REPLACE_WITH_MODULE_VERSION",
    packages=['python_models',
              'python_models.model_binaries',
              'python_models.neural_models'],
    package_data={'python_models.model_binaries': ['*.aplx']},
    install_requires=['SpyNNaker == 2015.005-rc-01']
)
