#ifndef _NEURON_MODEL_MY_IMPL_H_
#define _NEURON_MODEL_MY_IMPL_H_

#include <neuron/models/neuron_model.h>

typedef struct neuron_t {
    // Variable-state parameters e.g. membrane voltage
    REAL V;

    // offset current [nA]
    REAL I_offset;

    // rest voltage
    REAL V_rest;

    // decay value
    REAL decay;

    // threshold voltage
    REAL V_thresh;

    // rest voltage
    REAL V_reset;

    // Refractory period
    uint32_t t_refract;

    // Refractory counter
    int32_t t_refract_counter;

    // Spike probability
    uint32_t spike_probability;

} neuron_t;

typedef struct global_neuron_params_t {

    uint32_t seed[4];

} global_neuron_params_t;

// function that converts the input into the real value to be used by the
// neuron - this can be used for scaling for example
// (as is done for conductance)
inline input_t neuron_model_convert_input(input_t input) {
    return input;
}

#endif   // _NEURON_MODEL_MY_IMPL_H_
