from spynnaker.pyNN.models.abstract_models.abstract_population_vertex import \
    AbstractPopulationVertex
from spynnaker.pyNN.models.abstract_models.abstract_model_components\
    .abstract_exp_population_vertex import AbstractExponentialPopulationVertex

from spynnaker.pyNN.models.neural_properties.neural_parameter import \
    NeuronParameter

from data_specification.enums.data_type import DataType
from spynnaker.pyNN.utilities import utility_calls


class MyModelCurrExp(
        AbstractExponentialPopulationVertex,
        AbstractPopulationVertex):
    _model_based_max_atoms_per_core = 255

    def __init__(self, n_neurons, machine_time_step, timescale_factor,
                 spikes_per_second, ring_buffer_sigma, constraints=None,
                 label=None,
                 tau_syn_E=5.0,
                 tau_syn_I=5.0,
                 v_init=-65.0,
                 i_offset=0.0,
                 v_rest=-65.0,
                 decay=0.1,
                 v_thresh=-60.0,
                 v_reset=-70.0,
                 t_refract=5.0
                 ):
        AbstractPopulationVertex.__init__(
            self, n_neurons=n_neurons, label=label,
            n_params=8,
            n_global_params=0,
            binary="my_model_curr_exp.aplx",
            weight_scale=1.0,
            constraints=constraints,
            max_atoms_per_core=MyModelCurrExp._model_based_max_atoms_per_core,
            machine_time_step=machine_time_step,
            timescale_factor=timescale_factor,
            spikes_per_second=spikes_per_second,
            ring_buffer_sigma=ring_buffer_sigma)
        AbstractExponentialPopulationVertex.__init__(
            self, n_neurons=n_neurons, machine_time_step=machine_time_step,
            tau_syn_E=tau_syn_E, tau_syn_I=tau_syn_I)
        self._v_init = utility_calls.convert_param_to_numpy(v_init, n_neurons)
        self._i_offset = utility_calls.convert_param_to_numpy(
            i_offset, n_neurons)
        self._v_rest = utility_calls.convert_param_to_numpy(
            v_rest, n_neurons)
        self._decay = utility_calls.convert_param_to_numpy(
            decay, n_neurons)
        self._v_thresh = utility_calls.convert_param_to_numpy(
            v_thresh, n_neurons)
        self._v_reset = utility_calls.convert_param_to_numpy(
            v_reset, n_neurons)
        self._t_refract = utility_calls.convert_param_to_numpy(
            t_refract, n_neurons) * (machine_time_step / 1000.0)

    def initialize_v(self, v_init):
        self._v_init = utility_calls.convert_param_to_numpy(
            v_init, self.n_atoms)

    @property
    def i_offset(self):
        return self._i_offset

    @i_offset.setter
    def i_offset(self, i_offset):
        self._i_offset = utility_calls.convert_param_to_numpy(
            i_offset, self.n_atoms)

    @property
    def v_rest(self):
        return self._v_rest

    @v_rest.setter
    def v_rest(self, v_rest):
        self._v_rest = utility_calls.convert_param_to_numpy(
            v_rest, self.n_atoms)

    @property
    def decay(self):
        return self._decay

    @decay.setter
    def decay(self, decay):
        self._decay = utility_calls.convert_param_to_numpy(
            decay, self.n_atoms)

    @property
    def v_thresh(self):
        return self._v_thresh

    @v_thresh.setter
    def v_thresh(self, v_thresh):
        self._v_thresh = utility_calls.convert_param_to_numpy(
            v_thresh, self.n_atoms)

    @property
    def v_reset(self):
        return self._v_reset

    @v_reset.setter
    def v_reset(self, v_reset):
        self._v_reset = utility_calls.convert_param_to_numpy(
            v_reset, self.n_atoms)

    @property
    def t_refract(self):
        return self._t_refract

    @t_refract.setter
    def t_refract(self, t_refract):
        self._t_refract = utility_calls.convert_param_to_numpy(
            t_refract, self.n_atoms)

    @property
    def model_name(self):
        return "MyModel"

    @staticmethod
    def set_model_max_atoms_per_core(new_value):
        MyModelCurrExp._model_based_max_atoms_per_core = new_value

    def get_cpu_usage_for_atoms(self, vertex_slice, graph):
        return 781 * vertex_slice.n_atoms

    def get_parameters(self):
        return [
            NeuronParameter(self._v_init, DataType.S1615),
            NeuronParameter(self._i_offset, DataType.S1615),
            NeuronParameter(self._v_rest, DataType.S1615),
            NeuronParameter(self._decay, DataType.S1615),
            NeuronParameter(self._v_thresh, DataType.S1615),
            NeuronParameter(self._v_reset, DataType.S1615),
            NeuronParameter(self._t_refract, DataType.UINT32),
            NeuronParameter(0, DataType.INT32)
        ]

    def get_global_parameters(self):
        return [
        ]

    def is_population_vertex(self):
        return True

    def is_exp_vertex(self):
        return True
