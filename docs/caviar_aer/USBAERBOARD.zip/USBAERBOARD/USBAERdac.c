#include "mex.h"
#include "USBAERCommon.h"
#define NUM_PARAM_ENTRADA 2
#define NUM_PARAM_SALIDA 1




void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
  double *fpar,error=0, param1;
  int i,nfpar;
  unsigned long count = 0;
  unsigned long nWrite;
  unsigned long longitud;
  char buf[64];
  char par[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  
  // comprobacion del numero de parametros de entrada y salida.
  if((nrhs != 2)) 
    mexErrMsgTxt("Error. Input parameters don't match: [error,Array] = USBAERReceive(hnd,NumBytesToRec)");

   //if(nlhs != NUM_PARAM_SALIDA) 
  //  mexErrMsgTxt("Error. Output parameters don't match: [error] = USBAERSend(hnd,ArrayDat [,ArrayPar])");
    
  /* comprueba que el primer argumento es el manejador (un escalar). */
  if(!mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) || mxGetN(prhs[0])*mxGetM(prhs[0]) != 1 ) {
    mexErrMsgTxt("Parameter 1 is not an escalar.");   
  }  
  
    /* Comprueba que el segundo argumento es una matriz de eventos de nx1 */
  if(!mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || mxGetN(prhs[1])!=1 ) {
    mexErrMsgTxt("Parameter 2 is not a Nx1 numeric matrix.");   
  }  
  nfpar=mxGetM(prhs[1]);            
  if(nfpar>16)
    mexErrMsgTxt("Too many DAC parameters passed");
  
  fpar=mxGetPr(prhs[1]); //Parameter Vector
  for(i=0;i<nfpar;i++) par[i]=fpar[i]; //type conversion
     
  param1 = mxGetScalar(prhs[0]); // el manejador
  hDevice=LeerManejadorMatlab(param1);

  if (hDevice!=INVALID_HANDLE_VALUE){
      // Sending only one USB packet of 64 bytes
                        longitud = 0; 
                        buf[0]='A';
                        buf[1]='T';
                        buf[2]='C';
                        buf[3]= 4;   // command 4 for DAC configuration
                        for(i=4;i<8;i++)
                                buf[i]=0; // this command does not have data, only parameters
                        for(i=8;i<24;i++)
                                buf[i]=par[i-8];
                        WriteFile(hDevice, buf,(unsigned long) 64, &nWrite, NULL); //Write command
                        error=0;
  } else {
      error=1;
  }
  
  plhs[0]=mxCreateScalarDouble((double) error);
}
