function ev_out=Ev_JA2Ev_inMOD(ev_in)
%Funcion que recibe una matriz de eventos en el formato del programa de
%Jose Antonio y genera la correspondiente matriz de eventos para enviarsela
%a la funcion 'datalogger_send_new'
[nevents,ndata]=size(ev_in);
ev_out(1,2)=0; %tiempo
ev_out(1,1)=ev_in(1,5)*256+2*ev_in(1,4)+1*(ev_in(1,6)+1)/2; %direccion
% for i=2:nevents
%     ev_out(i,2)=ev_in(i,1)-ev_in(i-1,1); %tiempo
%     ev_out(i,1)=ev_in(i,5)*256+ev_in(i,4)+128*(ev_in(i,6)+1)/2; %direccion
% end
ev_out(2:nevents,2)=ev_in(2:nevents,1)-ev_in(1:nevents-1,1); %tiempo
ev_out(2:nevents,1)=ev_in(2:nevents,5)*256+2*ev_in(2:nevents,4)+1*(ev_in(2:nevents,6)+1)/2; %direccion