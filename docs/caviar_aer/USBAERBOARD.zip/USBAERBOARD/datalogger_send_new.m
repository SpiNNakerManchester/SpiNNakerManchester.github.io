function datalogger_send(tick,varargin)%tick,events_in,placa_in,placa_out
if nargin == 1
    [allAddr,allTs]=loadaerdat;
    allTs=double(allTs);
    timestamps=round(tick/10e-9)*[0;diff(allTs)]; 
    kk=find(timestamps==0);
    timestamps(kk)=3;
    convAddr=Ret2Conv(allAddr);
    events=[convAddr timestamps];
else
    events=varargin{1};
    hnd=varargin{2};
    events(:,2)=round(tick*events(:,2)/10e-9);
%     kk=find(events(:,2)==0);
%     events(kk,2)=1;
%    events(:,2)=events(:,2);
end
[a,b]=size(events);
events=events(1:min(a,2^19),:);
kk=find(events(:,2)>2^16);
for k=1:length(kk)
    if k<length(events)
        events=[events(1:(kk(k)+k-1)-1,:);[floor(events((kk(k)+k-1),2)/2^16) 2^16-1];[events((kk(k)+k-1),1) mod(events((kk(k)+k-1),2),2^16)];events((kk(k)+k-1)+1:end,:)];
    end
end
DatArray(1:4:length(events)*4)=bitshift(bitand(256*255,round(events(:,2))),-8);
DatArray(2:4:length(events)*4)=bitand(255,round(events(:,2)));
DatArray(3:4:length(events)*4)=bitshift(bitand(256*255,round(events(:,1))),-8);
DatArray(4:4:length(events)*4)=bitand(255,round(events(:,1)));
a=length(DatArray);
if a < 2^21
    aux=255*ones(1,2^21);
    aux(1:a)=DatArray;
%     DatArray=[DatArray 255 255 255 255];
%     a=a+4;
    DatArray=aux;
    a=2^21;
end
ini=1;
fin=2^18;
[hd,e]=USBAEROpen(hnd)
usbaersend(hd,0,6);
while ini < min(a,2^21)
    b=bitshift(bitand(256*256*7,(ini-1)/4),-16);
    c=bitshift(bitand(256*255,(ini-1)/4),-8);
    d=bitand(255,(ini-1)/4);
    usbaersend(hd,DatArray(ini:min(fin,a))',[4 3 b c d]'); 
    ini=ini+2^18;
    fin=fin+2^18;
end
usbaersend(hd,0,[1 3 0 0 0]');
usbaersend(hd,0,3);
% pause(0.5)
% usbaersend(hd,0,1);
e=usbaerclose(hd);