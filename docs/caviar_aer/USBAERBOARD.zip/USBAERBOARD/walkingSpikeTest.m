function [ spikeMatrix ] = walkingSpikeTest( spikeInterval, durationInSeconds )
%WALKINGSPIKETEST Summary of this function goes here
%   Detailed explanation goes here

durationInMicroseconds = durationInSeconds * 1000000;
sizeofMatrix = 0:spikeInterval:durationInMicroseconds;
% Calculate size of the spike matrix based on the given spike interval
sizeofMatrix = size(sizeofMatrix,2) ;

% jAER compatible format
spikeMatrix = zeros(sizeofMatrix,6);

time=0;
countM=1;
for y=0:127,
    for x=0:127,
        spikeMatrix(countM,:) = [time, 0, -1, x, y, 1];
        time = time+spikeInterval;
        countM=countM+1;

    end
end


end

