function [ correct_fpga_data ] = handle_wraparound( fpga_raw )
%HANDLE_WRAPAROUND Summary of this function goes here
%   Detailed explanation goes here
COUNTER_BITS = (2^16) - 1 ; 
wrapcounter  = 0;
old_valueip1 = fpga_raw(2);
old_v = fpga_raw(1);

for (i=1:length(fpga_raw)-2)
    if ((old_valueip1<old_v)) % && (fpga_raw(i)<COUNTER_BITS))
         wrapcounter=wrapcounter+1; % Increase every time there is a wrap around
    end
    
    old_valueip1 = fpga_raw(i+2);
    old_v = fpga_raw(i+1);
    fpga_raw(i+1)=fpga_raw(i+1)+ (COUNTER_BITS*wrapcounter);
end
    fpga_raw(end)=fpga_raw(end)+ (COUNTER_BITS*wrapcounter);

correct_fpga_data = fpga_raw;
end

