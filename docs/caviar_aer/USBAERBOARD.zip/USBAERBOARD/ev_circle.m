r=32;
c=64;
s=1;
Nev=4*r;

ev=zeros(Nev,6);
i=[1:Nev];
th=i*2*pi/Nev;
ev(:,1)=(i-1)*100;
ev(:,3)=-1;
ev(:,4)=round(c+r*cos(th));
ev(:,5)=round(c+r*sin(th));
ev(:,6)=s;

save ev_single ev