function [isi ] = return_isi( fpga_raw)
%CALCULATE_MEAN_ISI Summary of this function goes here
%   Detailed explanation goes here
for(i=1:size(fpga_raw,1)-1)
   isi(i)= ((fpga_raw(i+1)-fpga_raw(i)));
end
end

