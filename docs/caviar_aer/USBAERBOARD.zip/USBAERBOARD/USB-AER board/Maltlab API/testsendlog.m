%ori = [ 1 125 10 10 255 255 0 2 80 90 10 10 0 60 10 10]';
function varargout = testsendlog (varargin)
varargout{1} = 1;
varargout{2} = 1;
varargout{3} = 1;
if nargin == 0
    fprintf('\nSintax: [ResultMatrixMx4 SourceMatrixMx4 TargetMatrixMx4]= testsendlog(''devicenamesend'',''devicenamelog'',[''PatternMatrixMx1''])\n     or\n        ')
    fprintf('\nSintax: [ResultMatrixMx4 SourceMatrixMx4 TargetMatrixMx4]= testsendlog(''handlersend'',''handlerlog'',[''PatternMatrixMx1''])\n     or\n        ')
    return
elseif nargin ~= 3 && nargin ~= 2
    fprintf('Error. The number of arguments must be 3.\n')
    return
else    
    if isnumeric(varargin{1}) == 1
        he = varargin{1};
    elseif ischar(varargin{1}) == 1
       [he,e]=usbaeropen(varargin{1});
       if e ~= 0
          fprintf('Error. unknown device ''%s''\n', varargin{1})
          return
       end
    else
        fprintf('\nError. The parameter 1 must be a string or numeric.\n')
       return
    end

    if isnumeric(varargin{2}) == 1
        hd = varargin{2};
    elseif ischar(varargin{2}) == 1
       [hd,e]=usbaeropen(varargin{2});
       if e ~= 0
          fprintf('Error. unknown device ''%s''\n', varargin{2})
          return
       end
    else
        fprintf('\nError. The parameter 2 must be a string or numeric.\n')
       return
    end
end
if nargin == 3
   tam = size(varargin{3});
   if tam(1) ~= 1 || mod(tam(2),4) ~= 0
      fprintf('\nError. The parameter 3 must be a Row Vector multiple of 4.\n')
      return;
   end
   loops = floor(log2(32*256*256/tam(2)))+1;
   varargout{2} = varargin{3}';
   for cnt = 1:loops
      varargout{2} = [varargout{2};varargout{2}];
   end
   varargout{2}(1:2,1) =[0 0];
   varargout{2} = varargout{2}(1:32*256*256,1);
   fprintf('\nWritting Pattern.\n');
   usbaersend(he,varargout{2},[4 3 0 0 0]'); % Escritura
else
   fprintf('\nSkipping write.\n');
end

pause(1);
usbaersend(hd,0,[1 1 1 2 1]'); % Configuraci�n Modo terminal con bloqueo.
pause(1);
usbaersend(he,0,3) % Emisi�n de eventos.
pause(1);
fprintf('Logging.\n ');
usbaersend(hd,0,2) % Captura.
fprintf('Press anykey when end log.\n')
pause;
fprintf('Reading log.\n ');
varargout{3} = takelog(hd);

if nargin == 3
   varargout{2} = reshape(varargout{2},4,8*256*256)';
   tamori = size(varargout{2}); tamori = tamori(1);
   tamdst = size(varargout{3}); tamdst = tamdst(1);
   if  tamori == tamdst
      varargout{1} = [varargout{3}-varargout{2}];
   elseif tamori == tamdst + 1
      tamori = tamori - 1; 
      varargout{2} = varargout{2}(1:tamori,:);
      varargout{1} = [varargout{3}-varargout{2}];
   else
      fprintf('Error, I can not calculte the matrix.\n ')
   end
else
   varargout{1} = [];
   varargout{2} = [];
end