function error=usbaersendimage(h,fname,imrows)

fid=fopen(fname);
im=fread(fid,imrows*imrows,'uint8=>double',0);
error=usbaersend(h,im);