%function unaimagen(h,imrows)
'unaimagen'
[error, a]=usbaerreceive(h, imrows*imrows);


ima = reshape(a,imrows,imrows);
ima=transpose(ima);
image(ima);
colormap(MAP);



