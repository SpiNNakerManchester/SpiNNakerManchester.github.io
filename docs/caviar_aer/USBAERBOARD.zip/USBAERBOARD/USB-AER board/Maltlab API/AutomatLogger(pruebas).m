[hd,e]=usbaeropen('atc1')
fprintf('\nFin de la apertura del puerto del datalogger - PULSE TECLA PARA CONTINUAR')
pause
cd D:\trabajo\Datalogger\DataLoggerV1.1
fprintf('\nCargando el firm al datalogger')
usbaerloadfpga(hd,'datalogger.bin')
fprintf('\nFin de la carga del firm del datalogger - PULSE TECLA PARA CONTINUAR')
pause
cd D:\trabajo\Datalogger\recursos\bins
fprintf('\nInicada la captura')
usbaersend(hd,0,2);
fprintf('\nPulse tecla para interrumpir la captura y/o iniciar recepci�n de datos - PULSE TECLA PARA CONTINUAR')
pause
c = takelog('atc1');
pause
fprintf('\nFin de la recepci�n de datos - PULSE TECLA PARA CONTINUAR')
a = showlog(c);
fprintf('\nFin de la representaci�n de los datos')

