function varargout = showlog_interv (varargin)
varargout{1} = 1;
NEvents = 0;
step = 1;
if nargin == 0
    fprintf('Syntax: Matrix64X64 = showlog_interv(MatrixNx4 [,Step] [,Last_Element])\n');
    return
end
[x,y]=size(varargin{1});
if y ~= 4
    fprintf('Error. The Parameter 1 is not a Nx4 numeric matrix -> %dx%d.\n',x,y)
    return;
end
if nargin > 1
    if varargin{2} > x
       fprintf('Error. The step must be between 1 and %d.\n', floor(x/2))
       return
    else
       step = varargin{2};
    end
end
if nargin > 2
    if varargin{3} > x
       fprintf('Error. The number of elements must be between 1 and %d.\n', x)
       return
    else
       x = varargin{3};
    end
end
fprintf('<---------->\n ')
fprintf('\f')
v = x / 10;
varargout{1} = zeros(256,256);
cnt = step;
while cnt < x
   if cnt > v
      fprintf('\f')
      v = v + x / 10;
   end
   if varargin{1}(cnt,1)~= 255 || varargin{1}(cnt,2)~= 255
      varargout{1}(varargin{1}(cnt,3)+1,varargin{1}(cnt,4)+1) = varargout{1}(varargin{1}(cnt,3)+1,varargin{1}(cnt,4)+1)+1;    
      NEvents = NEvents + 1;
   end
   cnt = cnt + step;
end
fprintf('\n %d events processed.\n',NEvents)
maximo=max(max(varargout{1}));
image(varargout{1}*64/maximo)
colormap('gray');