function varargout = exhaustivetest (varargin)
clc
varargout{1} = 0;
if nargin == 0
    fprintf('\nSintax: [error] = exhaustivetest(''devicename'',''firmware.bin'',iterations) \n')
    return
elseif nargin ~= 3
    fprintf('Error. The number of arguments must be 3.\n')
    return
elseif ischar(varargin{1}) ~= 1
    fprintf('Error. The parameter 1 must be string.\n')
    return
elseif ischar(varargin{2}) ~= 1
    fprintf('Error. The parameter 2 must be string.\n')
    return
elseif isnumeric(varargin{3}) ~= 1
    fprintf('Error. The parameter 3 must be integer.\n')
    return
end
[hd,e]=usbaeropen(varargin{1});
if e ~= 0
   fprintf('Error. unknown device ''%s''\n', varargin{1})
   return
end
[e] = usbaerloadfpga(hd,varargin{2});
if e ~= 0
   fprintf('Error. unknown firmware ''%s''\n', varargin{2})
   return
end
for iterat=1:varargin{3}
    fprintf('\nIteration %d: ', iterat);
    fprintf('TestRW: ');
    % TestRW
    CounterL = 0;CounterM = 0;CounterH = 0;
    setaddress(hd,0);
    usbaersend(hd,0,5);
    pause(1);
    error = 0;
    for cntsend=1:8
       [e,s]=usbaerreceive(hd,262144);
       for cntpos=1:4:262144
          if s(cntpos) == CounterL && s(cntpos+1) == CounterL && s(cntpos+2) == CounterL && s(cntpos+3) == CounterL
             CounterL = mod(CounterL + 1,256);
             if CounterL == 0
                CounterM = mod(CounterM + 1,256);
                if CounterM == 0
                   CounterH = CounterH + 1;
                end
             end
          else
             fprintf(' Error\n   Error TestRW:[%d %d %d %d] => [%d %d %d %d]!!!',0,CounterH,CounterM,CounterL,s(cntpos),s(cntpos+1),s(cntpos+2),s(cntpos+3))
             error = 1;
             varargout{1} = 0;
             break;
          end
       end
       if error == 1
           break;
       end
    end
    if error == 0
        fprintf('OK; ');
    else
        continue;
    end   
    % Generando la matriz para las pruebas.
    clear patern;
    patern = floor(rand(32*256*256,1)*255);
    % Escribiendo la matriz.
    fprintf('Writting ')
    usbaersend(hd,patern,[4 3 0 0 0]');
    % Leyendo la Matriz
    fprintf('& Reading 1 ')
    setaddress(hd,0);
    read1 = [];
    for cntsend=1:8,
       pause(.5)
       [e,s]=usbaerreceive(hd,262144);
       read1 = [read1;s];
    end
    % Re-leyendo la Matriz
    read1 = reshape(read1,4,524288)';
    fprintf('& 2: ')
    setaddress(hd,0);
    read2 = [];
    for cntsend=1:8,
       pause(.5)
       [e,s]=usbaerreceive(hd,262144);
       read2 = [read2;s];
    end
    read2 = reshape(read2,4,524288)';    
    %Resultados de la lectura.
    resread = read1 == read2;
    if min(min(resread))== 0 % Hay errores
       numerrors = 524288 - sum(resread);
       varargout{1} = 1;
       fprintf('Error reading\n   Error reading: [%d %d %d %d]',numerrors(1),numerrors(2),numerrors(3),numerrors(4))
       [e, pos] = min(resread);
       tam = 524288;
       for i=1:4
          if e(i)==0 && pos(i) < tam
             tam = pos(i);
          end
       end
       fprintf(', First error in %d: ',tam);
       fprintf('[%d %d %d %d]<=>[%d %d %d %d]!!!',read1(tam,1),read1(tam,2),read1(tam,3),read1(tam,4),read2(tam,1),read2(tam,2),read2(tam,3),read2(tam,4));
       error = 1;
       continue
    else
       fprintf('same reading ');
    end

    %Resultdos de la escritura
    patern = reshape(patern, 4, 524288)';
    reswrite = patern == read1;
    if min(min(reswrite))== 0
       varargout{1} = 1;
       numerrors = 524288 - sum(reswrite);
       fprintf('and error writting\n   Error writting: [%d %d %d %d]',numerrors(1),numerrors(2),numerrors(3),numerrors(4))
       [e, pos] = min(reswrite);       
       tam = 524288;
       for i=1:4
          if e(i)==0 && pos(i)< tam
             tam = pos(i);
          end
       end
       fprintf(', First error in %d: ',tam);
       fprintf('[%d %d %d %d]<=>[%d %d %d %d]!!!',patern(tam,1),patern(tam,2),patern(tam,3),patern(tam,4),read1(tam,1),read1(tam,2),read1(tam,3),read1(tam,4));
       error = 1;
       continue
    else          
       fprintf('and writing ok.');
    end
end