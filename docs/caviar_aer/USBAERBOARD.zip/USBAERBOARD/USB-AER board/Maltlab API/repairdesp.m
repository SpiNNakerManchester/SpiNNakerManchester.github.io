function varargout = repairdesp (varargin)
varargout{1} = []; 
varargout{2} = []; 
varargout{3} = []; 

if nargin == 0
    fprintf('\nSintax: [ResultMatrixMx4, NewSourceMatrixMx4, NewTargetMatrixMx4]= repairdesp(SourceMatrixMx4, TargetMatrixMx4)\n')
    return
elseif nargin ~= 2
    fprintf('Error. The number of arguments must be 2.\n')
    return
else
    tmp1 = size(varargin{1}); tmp1 = tmp1(2);
    tmp2 = size(varargin{1}); tmp2 = tmp2(2);   
    if tmp1 ~= 4
        fprintf('\nError. The parameter 1 must be a Mx4 matrix.\n')
        return
    elseif tmp2 ~= 4
        fprintf('\nError. The parameter 2 must be a Mx4 matrix.\n')
        return
    end
end
varargout{1} = []; % La matriz de los recortes.
varargout{2} = varargin{1}; % La matriz origen.
varargout{3} = varargin{2}; % La matriz destino
tamori = size(varargout{2}); tamori = tamori(1);
tamdst = size(varargout{3}); tamdst = tamdst(1);
primero = 0;

if tamori == tamdst
   while true
      res = varargout{3}-varargout{2};
      evs1 = find(res(:,3),1);
      evs2 = find(res(:,4),1);
      if isempty(evs1)
         if isempty(evs2)
           if primero == 0
              fprintf('Glitch not found.\n');
           end
           return
         else
             pos = evs2;           
         end       
      else
         if isempty(evs2)
             pos = evs1;
         else
             pos = min(evs1,evs2);              
         end
      end
      primero = 1;
      fprintf('Erasing glitch at %d => [%d %d %d %d]\n',pos, varargout{3}(pos,1),varargout{3}(pos,2),varargout{3}(pos,3),varargout{3}(pos,4));
      tamori = tamori - 1;
      tamdst = tamdst - 1;
      varargout{1} = [varargout{1}; pos varargout{3}(pos,:)];
      varargout{2} = varargout{2}(1:tamori,:);
      varargout{3}(pos,:)=[]; % Eliminamos el glitch.
   end
else
   fprintf('Error. The sizes must be same\n');
end