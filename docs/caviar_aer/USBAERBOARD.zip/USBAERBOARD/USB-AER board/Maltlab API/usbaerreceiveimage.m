%function usbaerreceiveimage(h,imrows)
M=0:1:255;
MAP=[M;M;M];
MAP=MAP';
MAP=MAP/255;
[error, a]=usbaerreceive(h, imrows*imrows);
figure;
axis square;
colormap(MAP);
t = timer('TimerFcn','unaimagen','Period', 0.03,'ExecutionMode', 'FixedRate','StopFcn','stopframegrabber');
start(t);