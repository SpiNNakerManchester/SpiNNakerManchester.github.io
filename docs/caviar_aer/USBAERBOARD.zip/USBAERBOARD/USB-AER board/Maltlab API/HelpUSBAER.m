function [ ] = HelpUSBAER( )
%HELPPCIAER Shows help for USBAER Interface
%  
type('helpUSBaer.txt')