#include "mex.h"
#define TAM 256

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
  double *bufsal,*bufent, num_b,nrows, ncols, x, y,p;
  int i, j, a,u;


  bufent = mxGetPr(prhs[0]);     // la matriz de eventos
  nrows = mxGetM(prhs[0]); //dimensiones de la tabla de entrada
  ncols = mxGetN(prhs[0]);

  num_b=nrows*ncols;
  plhs[0] = mxCreateDoubleMatrix(TAM*TAM*8, 4, mxREAL);
  bufsal= mxGetPr(plhs[0]);



  a=0;
  for (i=0;i<TAM;i++)
	  for (j=0;j<TAM;j++)
		{
			if (a<nrows && bufent[a]==((i*TAM)+j)) // esta el elemento en la matriz de entrada?
			{
				for (u=1;u<9;u++)
				{
					if (bufent[a+u*nrows]==-1) //no emito el evento y es el ultimo
					{
						x=0;y=0;p=2;
					}
					else
					{
						x=(int)bufent[a+u*nrows]&0xFF;
						//x=(int);
						y=(int)bufent[a+u*nrows]&0xFF00;
						y=(int)y/256;
						p=0;
						if ((u==8)||bufent[a+((u+1)*nrows)]==-1) p=1;
					}
					bufsal[(u-1)*TAM*TAM+(i*TAM+j)]=x;
					bufsal[(u-1)*TAM*TAM+(i*TAM+j)+TAM*TAM*8]=y;
					bufsal[(u-1)*TAM*TAM+(i*TAM+j)+TAM*TAM*8*2]=p;
					bufsal[(u-1)*TAM*TAM+(i*TAM+j)+TAM*TAM*8*3]=255;
				}
				a++;
			}
			else // si el elemento no esta en la entrada no lo emito
			{
				x=0;y=0;p=2;
			bufsal[(i*TAM+j)]=x;
			bufsal[(i*TAM+j)+TAM*TAM*8]=y;
			bufsal[(i*TAM+j)+TAM*TAM*8*2]=p;
			bufsal[(i*TAM+j)+TAM*TAM*8*3]=0;
			}


		}



}
