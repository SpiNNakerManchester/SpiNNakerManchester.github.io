function error=usbaersendmappingtable(h,fname)

fid=fopen(fname);
im=fread(fid,1024*2048,'uint8=>double',0);
error=usbaersend(h,im);