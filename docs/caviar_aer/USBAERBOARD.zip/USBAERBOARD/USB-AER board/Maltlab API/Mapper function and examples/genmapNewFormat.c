#include "mex.h"
#define TAM 256

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[])
{
  double *bufsal,*bufent, num_b,nrows, ncols, r,p;
  unsigned int i, j, a,u,index;
  long unsigned int x, y ;

 
  bufent = mxGetPr(prhs[0]);     // la matriz de eventos
  nrows = mxGetM(prhs[0]); //dimensiones de la tabla de entrada
  ncols = mxGetN(prhs[0]);

  num_b=nrows*ncols;
  plhs[0] = mxCreateDoubleMatrix(TAM*TAM*8, 4, mxREAL);
  bufsal= mxGetPr(plhs[0]);



  a=0;
  for (i=0;i<TAM;i++)
	  for (j=0;j<TAM;j++)
		{
			index=a;
            if (a<nrows && bufent[index]==((i*TAM)+j)) // esta el elemento en la matriz de entrada?
			{
				for (u=0;u<8;u++)
				{
					index=a+((u*3+1)*nrows);
                    if (bufent[index]==-1) //no emito el evento y es el ultimo
                    {
                        x=0;y=0;r=1;p=0;
					}
					else
					{
						index=a+((u*3+1)*nrows);
                        p=bufent[index];//probabilidad
                        
                        index=a+((u*3+2)*nrows);
                        r=bufent[index]*2;// rep
                        
                        index=a+((u*3+3)*nrows);
                        x=(int)bufent[index]&0x00FF;
						y=(int)bufent[index]&0xff00;
						y=y/256;
						
                        index=a+((u*3)+4);
						if ((u==8)||bufent[index]==-1) r=(int)r|0x01;
					}
					bufsal[(i*TAM+j)*8+u]=x;
                    bufsal[(TAM*TAM*8)+((i*TAM)+j)*8+u]=y;
                    bufsal[(2*TAM*TAM*8)+((i*TAM)+j)*8+u]=r;
                    bufsal[(3*TAM*TAM*8)+((i*TAM)+j)*8+u]=p;

				
                    
                    //printf("a:%d d:%d q:%f\n ", a, (i*TAM)+j, q);
                           
				}
				a++;
			}
			else // si el elemento no esta en la entrada no lo emito
			{
				x=0;y=0;r=1;p=0;
                bufsal[((i*TAM)+j)*8]=x;
                bufsal[(TAM*TAM*8)+((i*TAM)+j)*8]=y;
                bufsal[(2*TAM*TAM*8)+((i*TAM)+j)*8]=r;
                bufsal[(3*TAM*TAM*8)+((i*TAM)+j)*8]=p;
				
				


			}
      }
}
