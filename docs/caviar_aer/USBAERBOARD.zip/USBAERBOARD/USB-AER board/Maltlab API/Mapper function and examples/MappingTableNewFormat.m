%DevName: is the Name of the device of the board ti program
%srcs: is a matrix with 2 up to 25, the 
%       the first column is the input events
%       the rest a the output events 
%       (three cols per output event: PROB, REP, AE
%       see newformatmapper.pdf)
function wgen=MappingTableNewFormat(DevName,srcs)

srcssize=size(srcs);
error=0;
e=0;
t=mod(srcssize(2)-1,3);
if srcssize(1)<=256*256 & srcssize(2)<=25 & t==0
    [hnd,e]=usbaeropen(DevName)
    if e==0
        
        e=usbaerloadfpga(hnd,'mapperNewFormat.bin');
        if e==0
           %lets go to generate the mapping table
            m1=(zeros(srcssize(1),25-srcssize(2)))-1;
            srcsa=[srcs m1];
            srcsa=sortrows(srcsa);           
            wgen=genmapNewFormat(srcsa);
            wgenr=reshape(wgen',[],1);
            %let's go to upload the mapping table to the USB-AER board
           e=usbaersend(hnd, wgenr);
            if e>0
                'An error occurred  when uploading the mapping table to the USB-AER board'
                error=1;
            end;
        else
            'An error occurred when uploading the FGPA code to the USB-AER board'
            error=2;
        end;
    else
        'An error occurred when opening the USB-AER board'
        error=3
    end;
else
    'error: matrix dimension is not correct'
    error=4;
end;

