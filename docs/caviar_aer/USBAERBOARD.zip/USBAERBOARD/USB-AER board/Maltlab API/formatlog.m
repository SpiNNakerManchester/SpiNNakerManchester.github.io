function varargout = formatlog (varargin)
varargout{1}= [];
ticks = 0;
if nargin == 0
    fprintf('\nConverts ticks to nanosecond');
    fprintf('\nSintax: MatrixNx3 = formatlog (MatrixNx4).\n')    
    varargout{1} = 1;
elseif nargin ~= 1
    fprintf('\nError. The number of arguments must be 1.\n')
    varargout{1} = 1;
else
   [x,y]=size(varargin{1});
   if y ~= 4
      fprintf('\nError. The Parameter 1 is not a Nx4 numeric matrix -> %dx%d.\n',x,y)
      varargout{1} = 1;
   else
       % Para aligerar el proceso dividimos la matriz en varias matrices de
       % 10000 filas.
       tam = size(varargin{1});
       if varargin{1}(tam(1),1) == 255 && varargin{1}(tam(1),2) == 255 %�Es el �ltimo valor un overflow?
          tam = tam(1) - 1;
       else
          tam = tam(1);
       end
       cotamin = 1;
       cotamax = cotamin + 10000;
       nummat = 0;
       fprintf('\n<-');
       while cotamax < tam;
          fprintf('-')
          nummat = nummat + 1;
          if varargin{1}(cotamax,1) == 255 && varargin{1}(cotamax,2) == 255 % para no dividir en un overflow
             cotamax = cotamax - 1;
          end
          matrices{nummat} = varargin{1}(cotamin:cotamax,:);
          cotamin = cotamax + 1;
          cotamax = cotamin + 10000;
       end
       fprintf('>\n ')
       nummat = nummat + 1;
       matrices{nummat} = varargin{1}(cotamin:tam,:);
       % Se recalculan los overflows y se les suma al tiempo del evento.
       for mat=1:nummat,
          matrices{mat}(1,5)=0; % Para redimensionar la fila.
          fprintf('\f')
          [tmp, fila] = max(matrices{mat});
              fila = fila(1,2);   % La fila de la marca de overflow.
          tam = size(matrices{mat});
          while matrices{mat}(fila,1) == 255 && matrices{mat}(fila,2) == 255 && fila < tam(1)
             ticks = (matrices{mat}(fila,3)*256 + matrices{mat}(fila,4)+1)* 65535; %%CALCULOCAMBIADO;CALCULOCAMBIADO;CALCULOCAMBIADO;
             matrices{mat}(fila + 1,5) = matrices{mat}(fila + 1,2) + ticks;
             tam = size(matrices{mat});
             matrices{mat}(fila,:)=[];   %Elimina la fila del overflow.
             tam(1) = tam(1) - 1;
             [maximos, fila] = max(matrices{mat});
             fila = fila(1,2);
          end
       end
       fprintf('\n ')
       varargout{1} = [];
       for mat=1:nummat
          fprintf('\f')
          matrices{mat}(:,2) = (matrices{mat}(:,1)*255 + matrices{mat}(:,2) + matrices{mat}(:,5))*10 ;
          varargout{1} = vertcat(varargout{1},matrices{mat}(:,2:4));
       end
   end
end

