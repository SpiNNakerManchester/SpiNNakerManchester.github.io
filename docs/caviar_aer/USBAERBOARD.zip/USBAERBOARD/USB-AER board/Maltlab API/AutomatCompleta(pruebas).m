cd D:\trabajo\usB-AER\datalogger\matlab
load _images.mat;
[he,e]=usbaeropen('atc3')
fprintf('\nFin de la apertura del puerto del emisor - PULSE TECLA PARA CONTINUAR')
pause
cd D:\trabajo\USB-AER\_Bins
fprintf('\nCargando el firm al emisor')
[e]=usbaerloadfpga(he,'64x64modulusexhaustive.bin')
fprintf('\nFin de la carga del firm al emisor - PULSE TECLA PARA CONTINUAR')
pause
usbaersend(he,diag,0)
fprintf('\nFin del env�o de la imagen al emisor - PULSE TECLA PARA CONTINUAR')
pause
[hd,e]=usbaeropen('atc1')
fprintf('\nFin de la apertura del puerto del datalogger - PULSE TECLA PARA CONTINUAR')
pause

cd D:\trabajo\usB-AER\datalogger\matlab
fprintf('\nCargando el firm al datalogger')
usbaerloadfpga(hd,'dataloggerv20c.bin.bin')
fprintf('\nFin de la carga del firm del datalogger - PULSE TECLA PARA CONTINUAR')
pause
cd D:\trabajo\Datalogger\recursos\bins
fprintf('\nInicada la captura')
usbaersend(hd,0,2);
fprintf('\nPulse tecla para interrumpir la captura y/o iniciar recepci�n de datos - PULSE TECLA PARA CONTINUAR')
pause
c = takelog('atc1');
pause
fprintf('\nFin de la recepci�n de datos - PULSE TECLA PARA CONTINUAR')
a = showlog(c);
fprintf('\nFin de la representaci�n de los datos')

