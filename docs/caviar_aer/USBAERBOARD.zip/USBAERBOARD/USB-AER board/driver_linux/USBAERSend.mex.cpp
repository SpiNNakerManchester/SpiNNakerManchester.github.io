/* 
	USBAERClose - mex file for closing the handle the USBAER board

	(c) Matthias Oster 2005
*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <mex.h>
#include "dprintf.h"
#include "usbaer.h"

#define USAGESTR "Usage: [error] = USBAERSend (handle, buf, params)"
#define BUFLEN 4096

void mexFunction (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	/* check input arguments */
	if ((nrhs < 2) || !mxIsNumeric(prhs[0]) || mxIsComplex(prhs[1])) {
		mexErrMsgTxt (USAGESTR);
	}
	/* check output arguments */
	if ((nlhs < 0) || (nlhs > 1)) {
		mexErrMsgTxt (USAGESTR);
	}
	
	/* input arguments */
	int handle = (int) mxGetScalar (prhs[0]);
	unsigned char *params = NULL;
	unsigned nparams = 0;
	if (nrhs>=3) {
		nparams = mxGetM(prhs[2])*mxGetN(prhs[2]);
		if (mxIsUint8(prhs[2])) {
			params = (unsigned char *) mxGetPr(prhs[2]);
		} else {
			params = new unsigned char[16];
			for (unsigned int i1=0; i1<nparams; i1++) {
				params[i1] = (char) (mxGetPr(prhs[2])[i1]);
			}
		}
	}

	void *buf = (void *) mxGetPr (prhs[1]);
	int buflen = mxGetNumberOfElements(prhs[1]) * mxGetElementSize(prhs[1]);
	
	// send to handle
	int error = sendtofpga (handle, buf, buflen, nparams, params);
	if (error < 0) {
		eprintf ("error sending to handle %d: %d (%s).", handle, error, strerror (errno));
	}
	if (nlhs >= 1) {
		plhs[0] = mxCreateScalarDouble((double) error);
	}
}

