function error = USBAERSend (handle, buf)
% error = USBAERSend (hnd, data)
%
% sends 'data' to the device with the handle hnd
%
% parameters:
%  handle: handle to device, obtained with USBAEROpen
%  buf: data block, which is sent bytewise to the device. You might want to use uint16 or similar.
%
% returns:
%  error: error code.

disp ('error: build the mex function with "make"');
