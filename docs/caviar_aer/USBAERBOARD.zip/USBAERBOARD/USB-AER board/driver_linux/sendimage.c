/* $Id: sendimage.c,v 1.1 2005/01/17 14:45:04 mao Exp $

(c) Matthias Oster 2004

*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
 
#include "usbaer.h"

#define USBDEVICE "/dev/usb/usbaer1"

int main (int argc, char **argv)
{
	void *buf;
	int handle;
	long bufsize, bufsize64;
	int ret;

	handle = open (argv[1], 0);
	if (handle < 0){
		fprintf (stderr, "error opening image file %s: %d (%s)\n", argv[1], handle, strerror (errno));
		exit (EXIT_FAILURE);
	}
	/* get size */
	bufsize = lseek (handle, 0, SEEK_END);
	bufsize64 = bufsize; //((bufsize >> 6) + 1) << 6;
	lseek (handle, 0, SEEK_SET);
	
	/* make buffer */
	buf = malloc (bufsize);
	if (buf==NULL) {
		fprintf (stdout, "could not reserve buffer of %ld bytes", bufsize);
		exit (EXIT_FAILURE);
	}
	/* load it */
	ret = read (handle, buf, bufsize);
	if (ret < -1) {
		fprintf (stdout, "sendimage read error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
	fprintf (stdout, "sendimage loaded from %s: %ld bytes\n", argv[1], bufsize);

	handle = open (USBDEVICE, O_RDWR);
	if (handle < 0) {
		fprintf (stderr, "error opening usbaer: %d (%s)\n", handle, strerror (errno));
		exit (EXIT_FAILURE);
	}

	fprintf (stdout, "uploading sendimage to %s: ", USBDEVICE);
	ret = sendtofpga (handle, buf, bufsize);
	if (ret < bufsize64) {
		fprintf (stderr, "usbaer write error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
	fprintf (stdout, "%d bytes ok.\n", ret);
	
	close (handle);
	return 0;
}
