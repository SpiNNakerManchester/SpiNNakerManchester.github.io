/* $Id: libusbaer.c,v 1.8 2005/01/17 14:45:04 mao Exp $

(c) Matthias Oster 2004

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "usbaer.h"

//#define DEBUG
#ifdef DEBUG
	#include "sysloghex.h"
#endif

#define URBLEN 64
#define CMDLEN URBLEN
#define MAXBUFFER 8*4096

#define UPLOADFIRMWARE 0
#define SENDTOFPGA 1
#define RECVFROMFPGA 2

#define min(a,b) a<b?a:b

/* write buffer, packaging into URBLEN pieces */
ssize_t writen (int handle, const void *buf, size_t buflen) {
	int ret;
	char ebuf[URBLEN];
	char *cbuf = (char *) buf;
	size_t nleft = buflen;
	while (nleft > 0) {
		#ifdef DEBUG
			sysloghex (LOG_ERR, (char*)cbuf, nleft);
		#endif
		if (nleft < URBLEN) {
			memcpy (ebuf, cbuf, nleft);
			cbuf = ebuf;
			nleft = URBLEN;
			printf ("filling up to URBLEN: now sending %d bytes.\n", nleft);
		}	
		ret = write (handle, cbuf, min(nleft,MAXBUFFER));	/* driver should not get a too big buffer at once */
		if (ret < 0)
			return ret;
		cbuf += ret;
		nleft -= ret;
	}
	return buflen - nleft;
}

/* read buffer, packaging into URBLEN pieces */
ssize_t readn (int handle, void *buf, size_t buflen) {
	int ret;
	char *cbuf = (char *) buf;
	size_t nleft = buflen;
	while (nleft > 0) {
		ret = read (handle, cbuf, nleft);	/* driver reads only one URB */
		if (ret < 0) {
			printf ("read %d bytes\n", buflen-nleft);
			return ret;
		}
		cbuf += ret;
		nleft -= ret;
	}
	return buflen - nleft;
}

/* format and send a command package */
int sendcmd (int handle, unsigned char cmdcode, unsigned long buflen, size_t paramlen, unsigned char *params) {
	unsigned char buf[CMDLEN] = "ATC";
	int i, ret;

	/* char 3: set command code */
	buf[3] = cmdcode;

	/* char 4-7: format buflen to little endian (Byte0, Byte1, Byte2, Byte3) */
	for(i=4; i<8; i++)
		buf[i] = (buflen >> (8*(i-4))) & 0xff;
		
	/* char 8-23: clear 16 reserved bytes */
	memset (&buf[8], 0, 16);
	if (paramlen > 0) {
		memcpy (&buf[8], params, paramlen);
	}
	
	/* write to device */
	ret = writen (handle, buf, CMDLEN);
	
#ifdef DEBUG
	sysloghex (LOG_ERR, (char*)buf, CMDLEN);
#endif

	/* set error code -1 if not all bytes transmitted (should not happen since this is one urb!) */
	if ((ret >= 0) && (ret < CMDLEN)) {
		ret = -1;
	}

	/* in success we return CMDLEN or directly the error */
	return ret;
}

int recvfromfpga (int handle, void *buf, size_t buflen, size_t paramlen, unsigned char *params) {
	int ret;
	int i1;	
	
	/* send command */
	ret = sendcmd (handle, RECVFROMFPGA, buflen, paramlen, params);
	if (ret < 0) {
		return ret;
	}

	/* recv buffer */
	ret = readn (handle, buf, buflen);
	return ret;
}
	
int sendtofpga (int handle, const void *buf, size_t buflen, size_t paramlen, unsigned char *params) {
	int ret;	
	
	/* send command */
	ret = sendcmd (handle, SENDTOFPGA, buflen, paramlen, params);
	if (ret < 0)
		return ret;
	
	/* send buffer */
	ret = writen (handle, buf, buflen);

	return ret;
}
	
int uploadfirmware (int handle, const void *buf, size_t buflen) {
	int ret;	
	
	/* send command */
	ret = sendcmd (handle, UPLOADFIRMWARE, buflen);
	if (ret < 0) {
		printf ("error %X", ret);
		return ret;
	}
	
	/* send buffer */
	ret = writen (handle, buf, buflen);

	/* send another package TODO */ 
	return ret;
}
