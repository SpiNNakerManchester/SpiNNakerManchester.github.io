function v = getFrameUsbaer

v1024 = reshape (MonFrame, 32, 32);
v = v1024(1:16, 1:16);
