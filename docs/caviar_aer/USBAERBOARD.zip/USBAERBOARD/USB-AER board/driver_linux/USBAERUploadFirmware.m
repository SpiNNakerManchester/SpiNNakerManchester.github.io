function error = USBAERUploadFirmware (handle, filename)
% error = USBAERUploadFirmware (handle, filename)
%
% sends 'data' to the device with the handle hnd
%
% parameters:
%  handle: handle to device, obtained with USBAEROpen
%  filename: strng to the filename
%
% returns:
%  error: error code.

disp ('error: build the mex function with "make"');
