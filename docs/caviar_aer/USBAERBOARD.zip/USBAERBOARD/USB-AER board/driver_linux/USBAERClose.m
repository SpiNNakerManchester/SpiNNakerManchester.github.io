function error = USBAERClose (handle)
% error = USBAERClose (handle)
%
% close the device with the handle handle
%
% parameters:
%  handle: handle to device, obtained with USBAEROpen
%
% returns:
%  error: error code.

disp ('error: build the mex function with "make"');
