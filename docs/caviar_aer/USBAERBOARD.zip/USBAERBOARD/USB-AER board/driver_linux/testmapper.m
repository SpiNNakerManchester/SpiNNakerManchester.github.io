% init
PciaerMonSetChannelSel(8)				% mapper connected to input channel D
PciaerSeqWrite (genStimulus (0, 1000, 10, 10))
PciaerMapSetMapping (n2addr(0,'seq'), 49152)		% mapper connected to output channel D
PciaerMapSetDemuxConfig
PciaerMapSetOutputConfig1toMany
PciaerMapSetChannelSel(4)

% create matrix
% the matrix is (x:([1=address,2=marker],p*256),y:input address,z:index of output address)
% x: 0=output address, go next marker; 1=last address; 2=no output.
z = uint16(2*ones(2,65536,8));	% initialize everything to output no address
z(1,1,1) = 0;
z(2,1,1) = 128*256;
%z = uint16(2*ones(2,65536,8));	% initialize everything to output no address
%z(1,1,:) = syn2addr(0:7, 'd3b', 'exc1') - 49152;	% input synapse addresses
%z(2,1,:) = 0;

% open board
h = USBAEROpen('atc4');
USBAERSend(h,z);

% record addresses
PciaerMonRecordEventsStart; pause (.1); ae = PciaerMonRecordEventsStop; unique(double(ae(1,:))) - 49152
