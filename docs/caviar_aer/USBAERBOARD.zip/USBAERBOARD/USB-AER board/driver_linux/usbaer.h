/* $Id: usbaer.h,v 1.2 2004/11/08 13:42:01 mao Exp $

(c) Matthias Oster 2004

*/
#ifndef __USBAER__
#define __USBAER__

int sendcmd (int handle, unsigned char cmdcode, unsigned long buflen, size_t paramlen=0, unsigned char *params=NULL);
int recvfromfpga (int handle, void *buf, size_t buflen, size_t paramlen=0, unsigned char *params=NULL);
int sendtofpga (int handle, const void *buf, size_t buflen, size_t paramlen=0, unsigned char *params=NULL);
int uploadfirmware (int handle, const void *buf, size_t buflen);

#endif
