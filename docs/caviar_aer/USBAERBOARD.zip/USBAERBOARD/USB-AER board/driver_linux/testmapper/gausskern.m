function z = gausskern
% z = gausskern
% init USBAER matrix with 1D gauss kernel
% (c) Matthias Oster 2005

% init everything to no output
z = uint16(2*ones(2,65536,7));
% create probs
nh = 3;		% half filter size (filter is 2*n+1)
n = 2*nh+1;
p = fspecial ('gaussian', [n 1], 1.5);
p = p / max(p);
p = round(p * 255)';
% neurons
all = zeros(16,16);
all(1:8,1:8) = 1;
neurons = find(all==1) - 1;
% retina pixels
pixels = n2addr(0:4095,'retina64','on');
pixels = reshape(reshape(pixels,64,64)',[],1);	% flip retina pixels
% go through all target neurons
for i1=(nh+1):(length(neurons)-nh)
	% get corresponding retina neurons
	rets = pixels((i1-1)*64 + (1:64));
	% put probability into matrix (upper byte)
	z(2,rets+1,1:n) = repmat(p,64,1) * 256;
	% addresses
	z(1,rets+1,1:n) = repmat(syn2addr(neurons((i1-nh):(i1+nh))','tncb1','exc1'),64,1);
	% mark last entry (add 1)
	z(2,rets+1,n) = z(2,rets+1,n) + 1;
end
