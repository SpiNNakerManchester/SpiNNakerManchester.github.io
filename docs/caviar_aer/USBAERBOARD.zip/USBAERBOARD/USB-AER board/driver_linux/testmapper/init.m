% init
PciaerMonSetChannelSel(8)				% mapper connected to input channel D
%PciaerSeqWrite (genStimulus (0, 1000, 10, 10))
%PciaerMapSetMapping (n2addr(0,'seq'), 49152)		% mapper connected to output channel D
PciaerMapSetDemuxConfig
PciaerMapSetOutputConfig1toMany
PciaerMapSetChannelSel(12)
PciaerMonSetChannelSel(15)

% PciaerSeqWrite (genPoisson (0:16383, 100*ones(16384,1), 1))
% set1to1 (n2addr(0:16382,'seq'), 49152:65534)
