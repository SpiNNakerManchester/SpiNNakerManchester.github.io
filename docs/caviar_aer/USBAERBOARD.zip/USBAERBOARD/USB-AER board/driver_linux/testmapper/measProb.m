function p = measProb (neurons)

set1to1 (n2addr(neurons), 49152+(neurons));
PciaerSeqWrite (genStimulus (neurons, 100*ones(length(neurons),1), 10, 10))

PciaerMonRecordEventsStart; pause(30); ae = PciaerMonRecordEventsStop;

sin=aeSortByNeuron(ae,n2addr(neurons,'seq'));
sout=aeSortByNeuron(ae,49152+neurons);
lin=sGetSpikeCounts(sin);
lout=sGetSpikeCounts(sout);
p=lout./lin;

save 'probtest0_255' ae neurons p
