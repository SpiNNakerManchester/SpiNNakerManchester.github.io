load probtest0_255
figure;
plot (0:255,p,'x');
xlabel('applied probability value');
ylabel('measured probability');
xlim([0 255]);
