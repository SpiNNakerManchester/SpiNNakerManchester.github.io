function z = gausskern
% z = gausskern
% init USBAER matrix with 1D gauss kernel
% (c) Matthias Oster 2005

% init everything to no output
z = uint16(2*ones(2,65536,1));
% neurons
all = zeros(16,16);
all(1:8,1:8) = 1;
neurons = find(all==1) - 1;
% retina pixels
pixels = n2addr(0:4095,'retina64','on');
pixels = reshape(reshape(pixels,64,64)',[],1);	% flip retina pixels
% go through all target neurons
for i1=1:length(neurons)
	% get corresponding retina neurons
	rets = pixels((i1-1)*64 + (1:64));
	% put probability 1 into matrix (upper byte)
	z(2,rets+1,1) = repmat(255,64,1) * 256;
	% addresses
	z(1,rets+1,1) = repmat(syn2addr(neurons(i1),'tncb1','exc1'),64,1);
	% mark last entry (add 1)
	z(2,rets+1,1) = z(2,rets+1,1) + 1;
end
