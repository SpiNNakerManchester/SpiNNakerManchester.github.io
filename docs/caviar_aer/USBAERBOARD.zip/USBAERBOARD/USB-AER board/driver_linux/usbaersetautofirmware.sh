#/bin/bash

if test $# -ne 2
then
	echo "Usage: $0 devname firmwarefile."
	exit;
fi
if test ! -f ${2}
then
	echo "'firmwarefile' has to be a regular, readable file."
	exit;
fi
FS=`/usr/bin/filesize "${2}"`;
if test $FS -ne 166980
then
	echo "'firmwarefile' has to be 166980 bytes."
	exit;
fi
echo "installing firmware '${1}' for device '${2}'."
install -m644 -o root -g root ${2} /usr/lib/firmwareusbaer/${1}
