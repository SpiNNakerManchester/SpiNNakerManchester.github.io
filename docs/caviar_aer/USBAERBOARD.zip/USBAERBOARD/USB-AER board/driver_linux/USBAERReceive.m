function [data, error] = USBAERReceive (handle, datalen_bytes)
% [data, error] = USBAERReceive (handle, datalen_bytes)
%
% receives the 'data' from the device with the handle hnd
%
% parameters:
%  handle: handle to device, obtained with USBAEROpen
%  datalen_bytes: length of the data block to receive in bytes. 
%
% returns:
%  data:  returned data. you might want to use uint16 or similar on the data to convert it to the format expected from the device.
%  error: error code.
%  NOTE: ORDER OF [DATA,ERROR] IS REVERSED COMPARED TO THE WINDOWS VERSION!

disp ('error: build the mex function with "make"');
