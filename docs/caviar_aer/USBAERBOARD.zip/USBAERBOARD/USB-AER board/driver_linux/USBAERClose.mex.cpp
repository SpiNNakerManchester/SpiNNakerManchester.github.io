/* 
	USBAERClose - mex file for closing the handle the USBAER board

	(c) Matthias Oster 2005
*/

extern "C" {
	#include <mex.h>
	#include "usbaer.h"
}
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include "dprintf.h"

#define USAGESTR "Usage: [error] = USBAERClose (handle)"
#define USBDEVICE "/dev/usb/usbaer0"		// override devicename until supported by system
#define BUFLEN 4096

void mexFunction (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	/* check input arguments */
	if ((nrhs != 1) && !mxIsNumeric(prhs[0])) {
		mexErrMsgTxt (USAGESTR);
	}
	/* check output arguments */
	if ((nlhs < 0) && (nlhs > 1)) {
		mexErrMsgTxt (USAGESTR);
	}
	
	/* input arguments */
	int handle = (int) mxGetScalar (prhs[0]);
	
	// open device
	int error = close (handle);
	if (error < 0) {
		eprintf ("error closing handle %d: %d (%s).", handle, error, strerror (errno));
	}
	plhs[0] = mxCreateScalarDouble((double) error);
}

