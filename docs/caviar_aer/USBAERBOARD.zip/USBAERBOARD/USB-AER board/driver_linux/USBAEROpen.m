function [hnd, error] = USBAEROpen (DeviceName)
% [hnd, error] = USBAEROpen (DeviceName)
%
% open the USBAER device called 'DeviceName', if it exists.
%
% returns:
%  hnd: handle to be used in further commands

disp ('error: build the mex function with "make"');
