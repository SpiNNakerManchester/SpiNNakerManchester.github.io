/* $Id: uploadfirmware.c,v 1.9 2005/01/18 10:35:18 mao Exp $

(c) Matthias Oster 2004

*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
 
#include "usbaer.h"

#define USBAERDIR "/dev/usbaer/"

int main (int argc, char **argv)
{
	void *buf;
	int handle;
	long bufsize, bufsize64;
	int ret;
	char devname[512];

	if (argc != 3) {
		fprintf (stderr, "Usage: uploadfirmware device_alias firmware (%d parameters given).\n", argc-1);
		exit (EXIT_FAILURE);
	}
	handle = open (argv[2], 0);
	if (handle < 0){
		fprintf (stderr, "error opening firmware file %s: %d (%s)\n", argv[2], handle, strerror (errno));
		exit (EXIT_FAILURE);
	}
	/* get size */
	bufsize = lseek (handle, 0, SEEK_END);
	bufsize64 = ((bufsize >> 6) + 1) << 6;
	lseek (handle, 0, SEEK_SET);
	
	/* make buffer */
	buf = malloc (bufsize64);
	if (buf==NULL) {
		fprintf (stdout, "could not reserve buffer of %ld bytes", bufsize64);
		exit (EXIT_FAILURE);
	}
	/* load it */
	ret = read (handle, buf, bufsize);
	if (ret < -1) {
		fprintf (stdout, "firmware read error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
	fprintf (stdout, "firmware loaded from %s: %ld bytes\n", argv[1], bufsize);

	/* build device name */
	strcpy (devname, USBAERDIR);
	strcat (devname, argv[1]);

	handle = open (devname, O_RDWR);
	if (handle < 0) {
		fprintf (stderr, "error opening %s: %d (%s)\n", devname, handle, strerror (errno));
		exit (EXIT_FAILURE);
	}

	fprintf (stdout, "uploading firmware to %s: ", devname);
	ret = uploadfirmware (handle, buf, bufsize64);
	if (ret < bufsize64) {
		fprintf (stderr, "usbaer write error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
	fprintf (stdout, "%d bytes ok.\n", ret);
	
	close (handle);
	return 0;
}
