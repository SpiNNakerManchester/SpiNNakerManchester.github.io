/* $Id: libusbaer.c,v 1.8 2005/01/17 14:45:04 mao Exp $

(c) Matthias Oster 2004

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "usbaer.h"

#define URBLEN 64
#define CMDLEN URBLEN

#define UPLOADFIRMWARE 0
#define SENDTOFPGA 1
#define RECVFROMFPGA 2

/* write buffer, packaging into URBLEN pieces */
ssize_t writen (int handle, const void *buf, size_t buflen) {
	int ret;
	char *cbuf = (char *) buf;
	size_t nleft = buflen;
	while (nleft > 0) {
		ret = write (handle, cbuf, nleft);	/* driver writes only one URB */
		if (ret < 0)
			return ret;
		cbuf += ret;
		nleft -= ret;
	}
	return buflen - nleft;
}

/* read buffer, packaging into URBLEN pieces */
ssize_t readn (int handle, void *buf, size_t buflen) {
	int ret;
	char *cbuf = (char *) buf;
	size_t nleft = buflen;
	while (nleft > 0) {
		ret = read (handle, cbuf, nleft);	/* driver reads only one URB */
		if (ret < 0) {
			printf ("read %d bytes\n", buflen-nleft);
			return ret;
		}
		cbuf += ret;
		nleft -= ret;
	}
	return buflen - nleft;
}

/* format and send a command package */
int sendcmd (int handle, unsigned char cmdcode, unsigned long buflen) {
	unsigned char buf[CMDLEN] = "ATC";
	int i, ret;

	/* char 3: set command code */
	buf[3] = cmdcode;

	/* char 4-7: format buflen to little endian (Byte0, Byte1, Byte2, Byte3) */
	for(i=4; i<8; i++)
		buf[i] = (buflen >> (8*(i-4))) & 0xff;
		
	/* char 8-23: clear 16 reserved bytes */
	memset (&buf[8], 0, 16);
	
	/* write to device */
	ret = writen (handle, buf, CMDLEN);
	
	/* set error code -1 if not all bytes transmitted (should not happen since this is one urb!) */
	if ((ret >= 0) && (ret < CMDLEN)) {
		printf ("wrote %d bytes\n", ret);
		ret = -1;
	}

	/* in success we return CMDLEN or directly the error */
	return ret;
}

int recvfromfpga (int handle, void *buf, size_t buflen) {
	int ret;
	int i1;	
	char ebuf[64];
	
	/* send command */
	ret = sendcmd (handle, RECVFROMFPGA, buflen); /*+URBLEN);*/
	if (ret < 0) {
		return ret;
	}

	/* recv buffer */
	ret = readn (handle, buf, buflen);

	return ret;
}
	
int sendtofpga (int handle, const void *buf, size_t buflen) {
	int ret;	
	
	/* send command */
	ret = sendcmd (handle, SENDTOFPGA, buflen);
	if (ret < 0)
		return ret;
	
	/* send buffer */
	ret = writen (handle, buf, buflen);

	return ret;
}
	
int uploadfirmware (int handle, const void *buf, size_t buflen) {
	int ret;	
	
	/* send command */
	ret = sendcmd (handle, UPLOADFIRMWARE, buflen);
	if (ret < 0) {
		printf ("error %X", ret);
		return ret;
	}
	
	/* send buffer */
	ret = writen (handle, buf, buflen);

	return ret;
}
