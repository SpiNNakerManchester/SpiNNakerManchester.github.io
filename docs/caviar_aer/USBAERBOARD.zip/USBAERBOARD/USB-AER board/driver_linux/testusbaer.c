/* $Id: testusbaer.c,v 1.8 2005/01/17 14:45:04 mao Exp $

(c) Matthias Oster 2004

*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

#include "usbaer.h"

#define USBDEVICE "/dev/usb/usbaer0"
#define BUFLEN 1024


int main ()
{
	unsigned char buf[BUFLEN];
	int handle;
	int ret;
	int i1;
	int i2;

	handle = open (USBDEVICE, O_RDWR | O_NONBLOCK);
	if (handle < 0) {
		fprintf (stderr, "error opening: %d (%s)\n", handle, strerror (errno));
		exit (EXIT_FAILURE);
	}
/*
	printf ("uploading firmware to %s: ", USBDEVICE);
	ret = uploadfirmware (handle, buf, 128);
	if (ret < 128) {
		fprintf (stdout, "write error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
	printf ("%d bytes ok.\n", ret);
	sleep (1);
*/

	
	printf ("requesting buffer from %s: ", USBDEVICE);
/*	for (i2=0; i2 < 1024; i2++) { */
	ret = recvfromfpga (handle, buf, 1024);
	if (ret < 1024) {
		fprintf (stdout, "error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
/*	} */
/*	for (i1=0; i1<1024; i1++) {
		if (buf[i1] != 0xCC) 
			printf ("value: %X.\n", buf[i1]);
	}
*/	printf ("%d bytes ok.\n", ret);


/*
	ret = write (handle, buf, 64);
*/	
/*	
	for (i1=0; i1 < 1; i1++) {
		printf ("trying to read extra urbs %d\n", i1);
		ret = read (handle, buf, 64);
		if (ret < 0) {
			fprintf (stdout, "read error: %d (%s)\n", ret, strerror (errno));
			exit (EXIT_FAILURE);
		}
	}
*/
/*
	printf ("sending buffer to %s: ", USBDEVICE);
	ret = sendtofpga (handle, buf, BUFLEN);
	if (ret < BUFLEN) {
		fprintf (stdout, "write error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
	printf ("%d bytes ok.\n", ret);
*/
	close (handle);
	return 0;
}
/*

int i;
unsigned long nWrite;

unsigned long longitud=1024;

        buf[0]='A';
        buf[1]='T';
        buf[2]='C';
        buf[3]= 2;   // comando 2 es leer RAM
        for(i=4;i<8;i++)
                buf[i]=(longitud>>(8*(i-4)))&0xff; //longitud.
	
        //WriteFile(hDevice, buf,(unsigned long)64, &nWrite, NULL);
		#define USBDEVICE "/dev/usb/usbaer0"
		int hDevice = open (USBDEVICE, O_RDWR | O_NONBLOCK);
		if (hDevice < 0) {
			fprintf (stderr, "open error open %s: %d (%s)\n", USBDEVICE, hDevice, strerror (errno));
			exit (EXIT_FAILURE);
		}
		fprintf (stdout, "device opened on handle %d\n", hDevice);

		int ret = write (hDevice, buf, 64);
		if (ret < 0) {
			fprintf (stderr, "write error: %d (%s)\n", ret, strerror (errno));
			exit (EXIT_FAILURE);
		}
		fprintf (stdout, "wrote %d of 64 bytes to the device\n", ret);

        //leer basurilla
        //ReadFile(hDevice, buf, (unsigned long)64, &nWrite, NULL);

		ret = read (hDevice, buf, 64);
		if (ret < 0) {
			fprintf (stderr, "read error: %d (%s)\n", ret, strerror (errno));
			exit (EXIT_FAILURE);
		}
		fprintf (stdout, "read %d bytes from the device\n", ret);

        for(i=0;i<longitud;i+=64) {
			ret = read (hDevice, &buf[i], 64);
			if (ret < 0) {
				fprintf (stderr, "read error: %d (%s)\n", ret, strerror (errno));
				exit (EXIT_FAILURE);
			}
			fprintf (stdout, "read %d bytes from the device\n", ret);
                //ReadFile(hDevice, &buf[i], (unsigned long)64, &nWrite, NULL);
		}
		close (hDevice);
		exit (0);
/*
int fila, col;
int x,y;
char *rowscan;

Image1->Picture->Assign  (imagen);


for (fila=0;fila<256;fila++)
{
        rowscan =(char *) Image1->Picture->Bitmap->ScanLine[fila];
        y=fila/8;
        for(col =0; col<256; col ++)
        {
        x=col /8;
        rowscan[3*col]= 8*buf[32*y+x];
        rowscan[3*col+1]= 8*buf[32*y+x];
        rowscan[3*col+2]= 8*buf[32*y+x];
         }
        }
}
//---------------------------------------------------------------------------

void __fastcall TFormReceive::FormClose(TObject *Sender,
      TCloseAction &Action)
{
    CloseHandle(hDevice);        
}
//---------------------------------------------------------------------------


*/

