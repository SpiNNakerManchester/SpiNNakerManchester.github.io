Installation
------------
see INSTALL.txt

Usage
-----
Use 
	usbaeruploadfirmware devalias firmwarefile
to upload firmware to the USB board with the name devalias

API
---
see
	usbaer.h
	
MATLAB
------
see the help included with the USBAER* files.
	
Auto-upload of firmware
-----------------------
use 
	sudo /usr/bin/usbaersetautofirmware devalias firmwarefile
to tell the system to automatically upload the firmwarefile to the device devalias as soon as it is plugged in.

--
(c) 2004 Matthias Oster, mao@ini.phys.ethz.ch
