/* 
	USBAERReceive - mex file for receiving data from the USBAER board

	(c) Matthias Oster 2005
*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <mex.h>
#include "dprintf.h"
#include "usbaer.h"

#define USAGESTR "Usage: [data,error] = USBAERReceive (handle, datalen_bytes, params)"
#define BUFLEN 4096

void mexFunction (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	/* check input arguments */
	if ((nrhs != 2) || !mxIsNumeric(prhs[0]) || !mxIsNumeric(prhs[1])) {
		mexErrMsgTxt (USAGESTR);
	}
	/* check output arguments */
	if ((nlhs < 0) || (nlhs > 3)) {
		mexErrMsgTxt (USAGESTR);
	}
	/* Checks third parameter if it exists */
	if (nrhs>=3) {
		if (!(mxIsUint8(prhs[2]) || mxIsDouble(prhs[2])) || mxIsComplex(prhs[2]) || (mxGetM(prhs[2])*mxGetN(prhs[2])<16)) {
			mexErrMsgTxt("Parameter 2 is not a uint8 or double matrix with >16 entries.");
		}
	}
 	
	/* input arguments */
	int handle = (int) mxGetScalar (prhs[0]);
	size_t datalen_bytes = (size_t) mxGetScalar (prhs[1]);
	unsigned char *params = NULL;
	unsigned nparams = 0;
	if (nrhs >= 3) {
		nparams = mxGetM(prhs[2])*mxGetN(prhs[2]);
		if (mxIsUint8(prhs[2])) {
			params = (unsigned char *) mxGetPr(prhs[2]);
		} else {
			params = new unsigned char[16];
			for (unsigned int i1=0; i1<nparams; i1++) {
				params[i1] = (char) (mxGetPr(prhs[2])[i1]);
			}
		}
	}
	
	/* create read buffer */
	plhs[0] = mxCreateNumericMatrix (1, datalen_bytes, mxUINT8_CLASS, mxREAL);
	void *data = (void *) mxGetPr (plhs[0]);
	
	// send to handle
	int error = recvfromfpga (handle, data, datalen_bytes, nparams, params);
	if (error < 0) {
		eprintf ("error sending to handle %d: %d (%s).", handle, error, strerror (errno));
	}
	
	if ((nrhs>=3) && (!mxIsUint8(prhs[2]))) {
		delete params;
	}
	if (nlhs < 1) {
		mxDestroyArray(plhs[0]);
	}
	if (nlhs >= 2) {
		plhs[1] = mxCreateScalarDouble((double) error);
	}
}

