/* 
	USBAEROpen - mex file for opening the USBAER board

	(c) Matthias Oster 2005
*/

extern "C" {
	#include <mex.h>
	#include "usbaer.h"
}
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include "dprintf.h"

#define USAGESTR "Usage: [handle, error] = USBAEROpen ('devicename')"
#define USBAERDIR "/dev/usbaer/"
#define BUFLEN 4096

void mexFunction (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	/* check input arguments */
	if ((nrhs != 1) || !mxIsChar(prhs[0])) {
		mexErrMsgTxt (USAGESTR);
	}
	/* check output arguments */
	if ((nlhs < 1) || (nlhs > 2)) {
		mexErrMsgTxt (USAGESTR);
	}
	
	// alias string
	unsigned aliaslen;
	char *alias;
	unsigned irhs = 0;
	if (nrhs > irhs) {
		if (mxIsChar (prhs[irhs])) {	
			aliaslen = (mxGetM(prhs[irhs]) * mxGetN(prhs[irhs])) + 1;
	    		alias = (char *) mxCalloc (aliaslen, sizeof(char));
	    		if (alias == NULL) {
				mexErrMsgTxt ("Not enough memory for copying strings.");
			}
			int status = mxGetString (prhs[irhs], alias, aliaslen);
	    		if (status != 0) {
				mexErrMsgTxt ("Not enough space for copying strings.");
			}
		} else {
			mexErrMsgTxt ("parameters must be a char array.");
		}
	}
	irhs++;
	
	int error = 0;	// assume no error
	
	char devname[BUFLEN]= USBAERDIR;
	strcat (devname, alias);
	
	// open device
	int handle = open (devname, O_RDWR | O_NONBLOCK);
	if (handle < 0) {
		eprintf ("error opening device %s: %d (%s).", devname, handle, strerror (errno));
		error = -1;
	}
	plhs[0] = mxCreateScalarDouble((double) handle);
	plhs[1] = mxCreateScalarDouble((double) error);
}

