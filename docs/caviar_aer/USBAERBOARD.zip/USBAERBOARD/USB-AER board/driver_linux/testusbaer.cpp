/* $Id: testusbaer.c,v 1.8 2005/01/17 14:45:04 mao Exp $

(c) Matthias Oster 2004

*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
 

#include "usbaer.h"

#define USBDEVICE "/dev/usbaer/atc4"
#define BUFLEN 64


int main ()
{
	unsigned char buf[BUFLEN];
	int params[BUFLEN];
	int handle;
	int ret;
	int i1;
	int i2;

	handle = open (USBDEVICE, O_RDWR | O_NONBLOCK);
	if (handle < 0) {
		fprintf (stderr, "error opening: %d (%s)\n", handle, strerror (errno));
		exit (EXIT_FAILURE);
	}

//	printf ("sending buffer to %s: ", USBDEVICE);

//while (true) {
	memset ((void *)buf, 0, BUFLEN);
	buf[2] = 3;
	buf[3] = 255;
	params[0] = rand()*8;
	params[1] = rand();
	ret = sendtofpga (handle, buf, BUFLEN); //, 4, (unsigned char*) params);
	if (ret < BUFLEN) {
		fprintf (stdout, "write error: %d (%s)\n", ret, strerror (errno));
		exit (EXIT_FAILURE);
	}
		
	printf ("%d bytes ok.\n", ret);
//}

	close (handle);
	return 0;
}
