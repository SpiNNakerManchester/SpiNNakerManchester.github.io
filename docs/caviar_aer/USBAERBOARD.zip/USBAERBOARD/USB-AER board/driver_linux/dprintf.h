/* debug output +LOG_DEBUG */
#ifdef VERBOSE
	#ifndef LOGLEVEL
		#define LOGLEVEL LOG_ERR
	#endif
	#define dprintf(level, format, arg...) syslog (level, format "\n" , ## arg); if (level <= LOGLEVEL) fprintf (stderr, format "\n" , ## arg)
	#define eprintf(format, arg...) syslog (LOG_ERR, format "\n" , ## arg); fprintf (stderr, format "\n" , ## arg)
#else
	#ifdef mex_h
		#define dprintf(level, format, arg...)
		#define eprintf(format, arg...) { char buf[1024]; sprintf(buf, format "\n", ## arg); mexErrMsgTxt(buf); }
	#else
		#define dprintf(level, format, arg...)
		#define eprintf(format, arg...) fprintf (stderr, format "\n" , ## arg); //syslog (LOG_ERR, format "\n" , ## arg); 
	#endif
#endif
