USBAER VHDL FPGA bin files
----------------------------
 FRAMEGRABBERS
---------------
64x64aer_framegrabber(200ms).bin	   200ms HW controlled timing 64x64 framegrabber no passthrough
64x64aer_framegrabberpassthr(notimer).bin  SW controlled timing 64x64 framegrabber passthrough
64x64aer_framegraberpassthr_conv.bin 	   idem but with conv polarity bit.
64x64aer_framegrabber(HWtimer).bin 	   programable hw timer (read framegrabber_HWtimer.txt) 64x64 framegrabber passthrough
128x128aer_framegrabber.bin		   framegrabber for 128 x 128 source
INIRET128x128aer_framegrabber.bin	   framegrabber for 128 x 128 ini Retina 
usb_aer_fg_24bits(vga).bin    		   VGA HW controlled timing (one frame) 64x64 framegrabber no passthrough

GENERATORS
----------
32x32frtoaerexahustivemodulus.bin   	32x32 exahustive gen 
64x64frtoaerUniform.bin 	    	64x64 uniform gen
64x64frtoaerexhaustivemodulus.bin   	64x64 exahustive gen
64x64frtoaerexhaustivemodulusdelay.bin	idem but req is delayed 80ns from the address
mapper_genera_exaustivo64.bin       	64x64 bitreverse exehus gen (generates more events a little more noisy)
64x64aer_random_usb_fifo.bin       	64x64  random  (generates as many events as bit reverse gaussian distribution)

MAPPERS
-------
mappermultievent.bin   	 		one to one mapper 
mappersingleevent.bin    		one to many mapper
mappermultieventprob.bin  		one to many stochastic mapper
mappermultieventprobNewFormat.bin	one to many stochastic mapper new format (see newformatmapper.pdf)
usbaermapper1to16repProb.bin		one to 16 mapper, take into account that only uses 15bits input addresses (14 to 0)
usbaermapper1to32repProb.bin		one to 32 mapper, take into account that only uses 14bits input addresses (13 to 0)
usbaermapper1to64repProb.bin		one to 64 mapper, take into account that only uses 13bits input addresses (12 to 0)


Datalogger
----------
dataloggerv122.bin	Datalogger version 1.22. Without Player

Filters
----------
repetitiousfilter.bin	eliminates the repetitious pixels (see filter.txt)
backgroundfilter.bin	eliminates the background activity  (see filter.txt)