

#include "C8051F320.H"

#include "micro.h"


#include "cyg_aux.h"
#include <intrins.h>
#include "USB_REGISTER.h"
#include "USB_DESCRIPTOR.h"

#define  firmware_file "FIRMWAREBIN"
#define  memory_file   "RAM     BIN"

#define OUT_DATA_READ_BY_APPL EA=0;POLL_WRITE_BYTE(INDEX, 2);POLL_WRITE_BYTE(EOUTCSR1, 0);EA=1; 
#define IN_DATA_SEND_BY_APPL EA=0;POLL_WRITE_BYTE(INDEX, 1);POLL_WRITE_BYTE(EINCSR1, rbInINPRDY);EA=1;


void upload_to_device(unsigned long);
void download_from_device(unsigned long);
void upload_descriptor_string();
void delayAER(void);

void sendSensorValue(unsigned char,unsigned int);
void sendConfigValue(unsigned char, unsigned int);
void sendValue(unsigned char dir, unsigned char msb, unsigned char lsb);
char SendByte(char byte);
void envia_parametros();

xdata unsigned char Out_Packet[64];   // Last packet received from host
xdata unsigned char In_Packet[64]  ;   // Next packet to sent to host



sfr16 	ADC0	= 0xBD;

sbit NSS=P0^3;
sbit STR=P0^4;
sbit RST_FPGA=P0^5;
sbit PD=P0^6;
sbit test=P0^7;

unsigned int statusRegister;
unsigned int bdata sensorEnable;
unsigned int mask;
unsigned int analogSensor[16];


bit entradapc;
bit salidapc;
idata unsigned int inp,outp;

xdata unsigned char sector[512];

extern code const BYTE String2DescF[STR2LEN];

/*****************************************************************************
* Function:     main

*****************************************************************************/
void main()
{
    unsigned char iErrorCode=0;
	unsigned long longitud;
	unsigned char comando;
	
 	unsigned int i,kk=0;

unsigned int value;
  
   // Disable Watchdog timer
PCA0MD &= ~0x40;                    // WDTE = 0 (clear watchdog timer
                                       // enable)
PORT_Init();                        // Initialize Port I/O
SYSCLK_Init ();                     // Initialize Oscillator
Usb0_Init(); 
REF0CN    = 0x2B;	//REF

	NSS=1; 		//Deseleccionamos al esclavo SPI
	RST_FPGA=1;	//Reseteamos la FPGA
	RST_FPGA=0;
	RST_FPGA=1;
	PD = 1;
//	sensorEnable=0xFFFF;	//Habilitamos por defecto la lectura de todos los sensores
//	statusRegister=0xD7FF;
//	run , todo PT, uno PFM, otro PWM, todos enable. y 1 bit no usado, propagamos eventos o no, y enables encoders
//	sendConfigValue(0x00,statusRegister); //Inicializamos el estado

// Entramos en el bucle para esperar ordenes del USB
entradapc=1;
salidapc=0;
OUT_DATA_READ_BY_APPL     // Clear Out Packe

for (i=0;i<64;i++)
	In_Packet[i]=0xff;


	In_Packet[32]=(unsigned char) (statusRegister/255);	//MSB
	In_Packet[33]=(unsigned char) (0x00FF & statusRegister);//LSB
	
	
  i=0;
  inp=0;
  outp=0;

  while(1){
	while(!salidapc) { 

		if (test) {
		  kk++;
        }

	}
	salidapc=0;

	if(Out_Packet[0]=='A' & Out_Packet[1]=='T' & Out_Packet[2]=='C')
		{
	  	comando =Out_Packet[3];
		longitud = (unsigned long)Out_Packet[4];
		longitud+=(unsigned long)Out_Packet[5]<<8;
		longitud+=(unsigned long)Out_Packet[6]<<16;
		longitud+=(unsigned long)Out_Packet[7]<<24;

        envia_parametros ();
		if (comando == 1) 
			upload_to_device(longitud);
		else if (comando == 2)
			download_from_device(longitud);
		else if (comando == 3)
			upload_descriptor_string();
		}
	else{salidapc =0;OUT_DATA_READ_BY_APPL}     // Clear Out Packe



	}   
}


void upload_to_device(unsigned long longitud)
{
    unsigned long i;
	
	for(i=0;i<longitud;i++){
	  	if ((i%64)==0){ // cada 64 bytes esperamos un nuevo paquete
			OUT_DATA_READ_BY_APPL     // Clear Out
			while(!salidapc);
			EA=0;salidapc =0;
		}
		//Poner Rutina atencion paquetes
		NSS=0; //Transferimos los 3 bytes.
		SendByte(0x00);
		SendByte(Out_Packet[i%64]);
		NSS=1;
		EA=1;
	   } 
	       OUT_DATA_READ_BY_APPL     // Clear Out Packet
	NSS=1;
}

void envia_parametros()
{
   char i;
   PD=0;
   for (i=8;i<24;i++) {
     EA=0;
	 NSS=0;
	 SendByte(0x00);
	 SendByte(Out_Packet[i]);
	 NSS=1;
	 EA=1;
   }
   if (Out_Packet[14]==1) {
	RST_FPGA=0;
	RST_FPGA=1;
   }     
   for (i=0;i<31;i++);
   PD=1;
}

void download_from_device(unsigned long longitud)
{
	//Actualizamos el valor del registro de estado
	In_Packet[32]=(unsigned char) (statusRegister/255);	//MSB
	In_Packet[33]=(unsigned char) (0x00FF & statusRegister);//LSB
	entradapc=1;
	OUT_DATA_READ_BY_APPL     // Clear Out Packe
	while(!entradapc);
	 entradapc =0;
	//EA=0;
	Fifo_Write1(FIFO_EP1, EP1_PACKET_SIZE, (BYTE *)In_Packet);
	//No limpiamos el paquete de salida
//       for(i=0;i<64;i++) In_Packet[i]=0x0;
			
	IN_DATA_SEND_BY_APPL
		 
}

void upload_descriptor_string(){

	OUT_DATA_READ_BY_APPL
	Page_Erase((char *)String2DescF);
	CopyDescStr((char *)&Out_Packet[8]);
}

//----------------------------------
//  FIFO Write
//----------------------------------
//
// Write to the selected endpoint FIFO
//
// Inputs:
// addr: target address
// uNumBytes: number of bytes to write
// pData: location of source data
//
void Fifo_Write1(BYTE addr, unsigned int uNumBytes, BYTE * pData)
{
   int i;
                                          
   // If >0 bytes requested,
   if (uNumBytes) 
   {
      while(USB0ADR & 0x80);              // Wait for BUSY->'0'
                                          // (register available)
      USB0ADR = (addr);                   // Set address (mask out bits7-6)

      // Write <NumBytes> to the selected FIFO
      for(i=0;i<uNumBytes;i++)
      {  
         USB0DAT = pData[i];
         while(USB0ADR & 0x80);           // Wait for BUSY->'0' (data ready)
      }
   }
}

void sendValue(unsigned char dir, unsigned char msb, unsigned char lsb){
	NSS=0; //Transferimos los 3 bytes.
	SendByte(dir);
	SendByte(msb);
	SendByte(lsb);
	NSS=1;	
}

void sendConfigValue(unsigned char dir, unsigned int value){
	unsigned char frame [3];
	frame[0]=(0x3F & dir)|0x40;
	frame[1]= (unsigned char) (value/256); //(cogemos el MSB)
	frame[2]= (unsigned char) (0x00FF & value);// (Tomamos el LSB)
	NSS=0; //Transferimos los 3 bytes.
	SendByte(frame[0]);
	SendByte(frame[1]);
	SendByte(frame[2]);
	NSS=1;	
}

void sendSensorValue(unsigned char sensor,unsigned int value){
	unsigned char frame [3];
	frame[0]=0x1F & sensor;
	frame[1]= (unsigned char) (value/256); //(cogemos el MSB)
	frame[2]= (unsigned char) (0x00FF & value);// (Tomamos el LSB)
	NSS=0; //Transferimos los 3 bytes.
	SendByte(frame[0]);
	SendByte(frame[1]);
	SendByte(frame[2]);
	NSS=1;
}

char SendByte(char byte){

  while(!TXBMT);  //wait for xmit buffer empty
  SPI0DAT=byte;

  while(!SPIF); //wait for end of transmition
  SPIF=0;  //clear SPIF
  
  return SPI0DAT;
}
