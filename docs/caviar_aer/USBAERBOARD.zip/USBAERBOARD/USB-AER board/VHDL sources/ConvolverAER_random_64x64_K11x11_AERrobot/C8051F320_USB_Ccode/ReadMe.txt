This Folder contains C8051F320 code for USB_AER Board
Changes

Bulk Mode
Descriptor string 2 in flash