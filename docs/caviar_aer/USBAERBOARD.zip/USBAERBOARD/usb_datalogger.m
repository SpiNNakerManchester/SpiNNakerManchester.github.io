function e=usb_datalogger(name)
%[h,e]=usbaeropen(name);
[h,e]=USBAEROpen(name);
if e~=0
    return;
end
e=USBAERloadFPGA(h,'dataloggerv23.bin');
if e~=0
    return;
end
e=usbaersend(h,0,[1 1 1 2 0 3 0 0 0]');
if e~=0
    return;
end
e=usbaerclose(h);
if e~=0
    return;
end
