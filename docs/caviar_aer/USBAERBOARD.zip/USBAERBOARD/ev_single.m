x=64;
y=64;
s=1;
Nev=1000;

ev=zeros(Nev,6);
i=[1:Nev];
ev(:,1)=(i-1)*100;
ev(:,3)=-1;
% ev(:,4)=mod(i,128);
% ev(:,5)=mod(i,128);
ev(:,4)=x;
ev(:,5)=y;
ev(:,6)=s;

save ev_single ev