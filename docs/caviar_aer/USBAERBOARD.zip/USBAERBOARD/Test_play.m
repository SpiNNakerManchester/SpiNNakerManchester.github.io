clear
%%configure usb-aer boards to generate events and store them
%  e1=usb_datalogger_fin('cnm0');
%e2=usb_datalogge_('cnm2')

%%
% Uploading the firmware
%
%-----------------------

% The following line will repeat the playback of events
% forever
e2=usb_datalogger('sil07')

% The following line will repeat the playback of events
% once
%e2=usb_datalogger_fin('sil07') % run only once

%%    
%loading input event stream
%   
    %Loading the Matrix with the events, it will look
    %for a variable with the name cin
    load walkingISI128x128_1000us.mat

    ev_pos=cin; %recorded timestamps

    evWALKING=Ev_JA2Ev_inMOD2(ev_pos);  %events have sign bit at 0 --bern

    datalogger_send_new(1e-6,evWALKING,'sil07');

%     datalogger_send_new(1,events,'cnm0');
